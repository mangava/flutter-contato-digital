global.SALT_KEY = 'f5b99242-6504-4ca3-90f2-05e78e5761ef';
global.EMAIL_TMPL = 'Olá, <strong>{0}</strong>, seja bem vindo a Node Store';

module.exports = {
    connectionString: 'mongodb+srv://anderson:anderson@cluster0-ub3l1.mongodb.net/test',
    sendgridkey:'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',
    containerConnectionString:'DefaultEndpointsProtocol=https;AccountName=nodestorage2;AccountKey=VD4sBEOPB/H1L/rzyQUUUjnEmC1EfcK66NkQSGc6fng4l89+w1Vu8jyE3VGh1hQWdBWlzf93RTIYZUspYfkXWg==;EndpointSuffix=core.windows.net',    
}